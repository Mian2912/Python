def saludar():
    print("hola, te estoy saludando de la funcion saludar del modulo saludos")

class Saludo():
    def __init__ (self):
        print("hola, te estoy saludando desde el init de la clase Saludo")
